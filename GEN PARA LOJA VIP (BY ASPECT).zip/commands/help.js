const { MessageEmbed, Message } = require('discord.js');
const config = require('../config.json');

module.exports = {
	name: 'help', 
	description: 'Mostra lista de Comandos.',
    
	execute(message) {
		const { commands } = message.client;
        
        message.channel.send(
            new MessageEmbed()
            .setTitle(`${config.subtitulo} | Meus Comandos`)
            .setDescription(`
**<:certo:1162626281213534278> | Help** - *Veja meus comandos*
**<:certo:1162626281213534278> | Stock** - *Veja meus serviços*
**<:certo:1162626281213534278> | Invite** - *Veja como me comprar*
**<:certo:1162626281213534278> | Gen** - *Gere algum serviço*
**<:certo:1162626281213534278> | Check** - *Cheque algum serviço*`)
            .setThumbnail(config.thumbnail)
            .setColor(config.color)
        );
	}
};